﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ShortcutReplacer
{
    public class TrayApp : Form
    {
        private NotifyIcon trayIcon;
        private ContextMenuStrip trayMenu;

        // Keyboard hook constants
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_KEYUP = 0x0101;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_SYSKEYUP = 0x0105;

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        private static LowLevelKeyboardProc _keyboardProc = KeyboardHookCallback;
        private static IntPtr _hookId = IntPtr.Zero;
        private static IntPtr _moduleHandle = IntPtr.Zero;

        private static StringBuilder _inputBuffer = new StringBuilder();
        private static volatile bool _isProcessing = false;
        private static Keys _lastKey = Keys.None;

        // Define your shortcuts here (now loaded from file)
        private static Dictionary<string, string> _shortcuts = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public TrayApp()
        {
            // Load shortcuts from file
            LoadShortcutsFromFile();

            var boldItem = new ToolStripMenuItem("Key Hooker v2.0");
            boldItem.Font = new Font(boldItem.Font, FontStyle.Bold);
            boldItem.Enabled = false;

            // Create the context menu
            trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("Reload Shortcuts", null, ReloadShortcuts);
            trayMenu.Items.Add("Exit", null, OnExit);
            trayMenu.Items.Add(new ToolStripSeparator());
            trayMenu.Items.Add(boldItem);

            // Create the tray icon
            trayIcon = new NotifyIcon
            {
                Text = "Running",
                ContextMenuStrip = trayMenu,
                Visible = true
            };

            // Load the icon
            try
            {
                trayIcon.Icon = new System.Drawing.Icon("logo.ico");
            }
            catch
            {
                trayIcon.Icon = SystemIcons.Application;
            }

            // Set up the keyboard hook
            SetKeyboardHook();
        }

        protected override void OnLoad(EventArgs e)
        {
            Visible = false;
            ShowInTaskbar = false;
            base.OnLoad(e);
        }

        private void OnExit(object sender, EventArgs e)
        {
            trayIcon.Visible = false;
            UnhookWindowsHookEx(_hookId);
            Application.Exit();
        }

        private void ReloadShortcuts(object sender, EventArgs e)
        {
            LoadShortcutsFromFile();
            MessageBox.Show("Shortcuts have been reloaded successfully.",
                          "Shortcuts Reloaded",
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Information);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TrayApp());
        }

        private static void LoadShortcutsFromFile()
        {
            _shortcuts.Clear();
            string filePath = "shortcuts.txt";

            if (!File.Exists(filePath))
            {
                // Create a default shortcuts file if it doesn't exist
                File.WriteAllLines(filePath, new[] 
                {
                    "# This is a comment",
                    "# Feel free to contact me",
                    "# Please use only text and numbers.",
                    " ",
                    "//name=Your Name",
                    "//mail=user@example.com",
                    "//phone=1234567890",
                });

                MessageBox.Show("A default shortcuts.txt file has been created. " +
                              "You can edit this file to customize your shortcuts.",
                              "Shortcuts File Created",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line) || line.TrimStart().StartsWith("#"))
                        continue;

                    var parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length == 2)
                    {
                        string shortcut = parts[0].Trim();
                        string replacement = parts[1].Trim();

                        if (!string.IsNullOrEmpty(shortcut) && !string.IsNullOrEmpty(replacement))
                        {
                            _shortcuts[shortcut] = replacement;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading shortcuts: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void SetKeyboardHook()
        {
            using (var currentProcess = Process.GetCurrentProcess())
            using (var mainModule = currentProcess.MainModule)
            {
                _moduleHandle = GetModuleHandle(mainModule.ModuleName);
                _hookId = SetWindowsHookEx(WH_KEYBOARD_LL, _keyboardProc, _moduleHandle, 0);
            }
        }

        private static IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && !_isProcessing)
            {
                int vkCode = Marshal.ReadInt32(lParam);
                Keys key = (Keys)vkCode;
                int msg = wParam.ToInt32();

                // Only process key down events
                if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)
                {
                    // Handle special keys
                    if (key == Keys.Back && _inputBuffer.Length > 0)
                    {
                        _inputBuffer.Remove(_inputBuffer.Length - 1, 1);
                    }
                    else if (key == Keys.Space)
                    {
                        _inputBuffer.Append(' ');
                    }
                    else if (key == Keys.OemQuestion || key == Keys.Oem5 || key == Keys.Divide) // / key
                    {
                        _inputBuffer.Append('/');
                    }
                    else if (key == Keys.OemPeriod)
                    {
                        _inputBuffer.Append('.');
                    }
                    else if (key >= Keys.A && key <= Keys.Z)
                    {
                        bool isShiftPressed = (GetKeyState(Keys.ShiftKey) & 0x8000) != 0;
                        bool isCapsLock = Control.IsKeyLocked(Keys.CapsLock);
                        bool shouldCapitalize = isShiftPressed ^ isCapsLock;

                        char c = (char)('a' + (key - Keys.A));
                        _inputBuffer.Append(shouldCapitalize ? char.ToUpper(c) : c);
                    }
                    else if (key >= Keys.D0 && key <= Keys.D9)
                    {
                        _inputBuffer.Append((char)('0' + (key - Keys.D0)));
                    }

                    _lastKey = key;

                    // Check for shortcuts
                    CheckForShortcuts();
                }
            }

            return CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        private static void CheckForShortcuts()
        {
            string currentInput = _inputBuffer.ToString();

            foreach (var shortcut in _shortcuts)
            {
                if (currentInput.EndsWith(shortcut.Key))
                {
                    _isProcessing = true;

                    // Use a separate thread to handle the replacement to avoid timing issues
                    ThreadPool.QueueUserWorkItem(state =>
                    {
                        // Small delay to ensure the characters are actually typed
                        Thread.Sleep(50);

                        // Erase the shortcut
                        for (int i = 0; i < shortcut.Key.Length; i++)
                        {
                            SendKeys.SendWait("{BACKSPACE}");
                            Thread.Sleep(10); // Small delay between backspaces
                        }

                        // Send the replacement text
                        SendKeys.SendWait(shortcut.Value);

                        // Clear the buffer on the UI thread
                        Application.OpenForms[0]?.Invoke(new Action(() =>
                        {
                            _inputBuffer.Clear();
                            _isProcessing = false;
                        }));
                    });

                    break;
                }
            }

            // Limit buffer size
            if (_inputBuffer.Length > 50)
            {
                _inputBuffer.Remove(0, _inputBuffer.Length - 30);
            }
        }

        // Clean up any resources being used
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                trayIcon?.Dispose();
                trayMenu?.Dispose();
            }

            if (_hookId != IntPtr.Zero)
                UnhookWindowsHookEx(_hookId);

            base.Dispose(disposing);
        }

        #region Native Methods

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        private static extern short GetKeyState(Keys nVirtKey);

        #endregion
    }
}